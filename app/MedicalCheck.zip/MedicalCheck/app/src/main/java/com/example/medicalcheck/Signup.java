package com.example.medicalcheck;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Signup extends AppCompatActivity {
    private EditText etEmail, etPassword;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);


        mAuth = FirebaseAuth.getInstance();
        connectComponents();


        private void connectComponents () {
            etEmail = findViewById(R.id.etEmailMain);
            etPassword = findViewById(R.id.etPasswordMain);
            etPassword1 = findViewById(R.id.etPasswordMain1);
        }

        public void signup (View view){

            String email = etEmail.getText().toString();
            String password = etPassword.getText().toString();
            String password1 = etPassword1.getText().toString();
            if (!password.equals(password1)) {
                etPassword.setError("passwords Must be the same");
                return;
            }


            if (password.length() < 6) {
                etPassword.setError("password Must be >= 6 Characters");
                return;
            }

            mAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(Signup.this, "User Created", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                            }
//
                            else {
                                Toast.makeText(Signup.this, "Error !" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            }

                        }
                    });
        }
    }
}
