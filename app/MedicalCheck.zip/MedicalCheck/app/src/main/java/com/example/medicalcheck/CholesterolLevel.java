package com.example.medicalcheck;

public class CholesterolLevel {
    private double HDL;
    private double LDL;

    public CholesterolLevel() {
    }

    public CholesterolLevel(double HDL, double LDL) {
        this.HDL = HDL;
        this.LDL = LDL;
    }

    public double getHDL() {
        return HDL;
    }

    public void setHDL(double HDL) {
        this.HDL = HDL;
    }

    public double getLDL() {
        return LDL;
    }

    public void setLDL(double LDL) {
        this.LDL = LDL;
    }

    @Override
    public String toString() {
        return "CholesterolLevel{" +
                "HDL=" + HDL +
                ", LDL=" + LDL +
                '}';
    }
}
