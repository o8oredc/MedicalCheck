package com.example.medicalcheck;

public class User {

    private String name;

    private int age;
    private double weight;
    private double height;
    private BloodPressure bloodPressure;
    private CholesterolLevel cholesterolLevel;
    private double glucosePer;
    private double bodyTemperature;


    public User() {
    }

    public User(String name, int age, double weight, double height, BloodPressure bloodPressure, CholesterolLevel cholesterolLevel, double glucoseLevel, double bodyTemperature) {
        this.name = name;

        this.age = age;
        this.weight = weight;
        this.height = height;
        this.bloodPressure = bloodPressure;
        this.cholesterolLevel = cholesterolLevel;
        this.glucosePer = glucoseLevel;
        this.bodyTemperature = bodyTemperature;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }





    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public BloodPressure getBloodPressure() {
        return bloodPressure;
    }

    public void setBloodPressure(BloodPressure bloodPressure) {
        this.bloodPressure = bloodPressure;
    }

    public CholesterolLevel getCholesterolLevel() {
        return cholesterolLevel;
    }

    public void setCholesterolLevel(CholesterolLevel cholesterolLevel) {
        this.cholesterolLevel = cholesterolLevel;
    }

    public double getGlucosePer() {
        return glucosePer;
    }

    public void setGlucosePer(double glucoseLevel) {
        this.glucosePer = glucoseLevel;
    }

    public double getBodyTemperature() {
        return bodyTemperature;
    }

    public void setBodyTemperature(double bodyTemperature) {
        this.bodyTemperature = bodyTemperature;
    }

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", weight=" + weight +
                ", height=" + height +
                ", bloodPressure=" + bloodPressure +
                ", cholesterolLevel=" + cholesterolLevel +
                ", glucosePer=" + glucosePer +
                ", bodyTemperature=" + bodyTemperature +
                '}';
    }
}
