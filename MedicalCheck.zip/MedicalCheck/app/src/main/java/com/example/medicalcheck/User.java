package com.example.medicalcheck;

public class User {

    private String name;
    private String FamilyName;
    private String Username;
    private int id;
    private int age;
    private double weight;
    private double height;
    private BloodPressure bloodPressure;
    private CholesterolLevel cholesterolLevel;
    private double glucosePer;
    private double bodyTemperature;


    public User() {
    }



    public User(String name,String FamilyName,String Username, int id, int age, double weight, double height, BloodPressure bloodPressure, CholesterolLevel cholesterolLevel, double glucoseLevel, double bodyTemperature) {
        this.name = name;
        this.id = id;
        this.FamilyName=FamilyName;
        this.Username=Username;
        this.age = age;
        this.weight = weight;
        this.height = height;
        this.bloodPressure = bloodPressure;
        this.cholesterolLevel = cholesterolLevel;
        this.glucosePer = glucoseLevel;
        this.bodyTemperature = bodyTemperature;
    }

    public String getName() {
        return name;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getFamilyName() {
        return FamilyName;
    }

    public void setFamilyName(String familyName) {
        FamilyName = familyName;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public BloodPressure getBloodPressure() {
        return bloodPressure;
    }

    public void setBloodPressure(BloodPressure bloodPressure) {
        this.bloodPressure = bloodPressure;
    }

    public CholesterolLevel getCholesterolLevel() {
        return cholesterolLevel;
    }

    public void setCholesterolLevel(CholesterolLevel cholesterolLevel) {
        this.cholesterolLevel = cholesterolLevel;
    }

    public double getGlucosePer() {
        return glucosePer;
    }

    public void setGlucosePer(double glucoseLevel) {
        this.glucosePer = glucoseLevel;
    }

    public double getBodyTemperature() {
        return bodyTemperature;
    }

    public void setBodyTemperature(double bodyTemperature) {
        this.bodyTemperature = bodyTemperature;
    }

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", FamilyName='" + FamilyName + '\'' +
                ", Username='" + Username + '\'' +
                ", id=" + id +
                ", age=" + age +
                ", weight=" + weight +
                ", height=" + height +
                ", bloodPressure=" + bloodPressure +
                ", cholesterolLevel=" + cholesterolLevel +
                ", glucosePer=" + glucosePer +
                ", bodyTemperature=" + bodyTemperature +
                '}';
    }
}
