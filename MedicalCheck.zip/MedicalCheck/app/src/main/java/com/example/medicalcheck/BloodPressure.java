package com.example.medicalcheck;

public class BloodPressure {

    private double low;
    private double high;

    public BloodPressure() {
    }

    public BloodPressure(double low, double high) {
        this.low = low;
        this.high = high;
    }

    public double getLow() {
        return low;
    }

    public void setLow(double low) {
        this.low = low;
    }

    public double getHigh() {
        return high;
    }

    public void setHigh(double high) {
        this.high = high;
    }

    @Override
    public String toString() {
        return "BloodPressure{" +
                "low=" + low +
                ", high=" + high +
                '}';
    }


}
