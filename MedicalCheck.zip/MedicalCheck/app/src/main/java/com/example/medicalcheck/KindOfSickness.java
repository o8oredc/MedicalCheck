package com.example.medicalcheck;

public class KindOfSickness {
    private boolean BloodPressure;
    private boolean Bmi;
    private boolean CholesterolLevel;
    private boolean glucosePer;
    private boolean bodyTemperature;

    public KindOfSickness() {
    }

    public KindOfSickness(boolean bloodPressure, boolean bmi, boolean cholesterolLevel, boolean glucosePer, boolean bodyTemperature) {
        BloodPressure = bloodPressure;
        Bmi = bmi;
        CholesterolLevel = cholesterolLevel;
        this.glucosePer = glucosePer;
        this.bodyTemperature = bodyTemperature;
    }

    public boolean isBloodPressure() {
        return BloodPressure;
    }

    public void setBloodPressure(boolean bloodPressure) {
        BloodPressure = bloodPressure;
    }

    public boolean isBmi() {
        return Bmi;
    }

    public void setBmi(boolean bmi) {
        Bmi = bmi;
    }

    public boolean isCholesterolLevel() {
        return CholesterolLevel;
    }

    public void setCholesterolLevel(boolean cholesterolLevel) {
        CholesterolLevel = cholesterolLevel;
    }

    public boolean isGlucosePer() {
        return glucosePer;
    }

    public void setGlucosePer(boolean glucosePer) {
        this.glucosePer = glucosePer;
    }

    public boolean isBodyTemperature() {
        return bodyTemperature;
    }

    public void setBodyTemperature(boolean bodyTemperature) {
        this.bodyTemperature = bodyTemperature;
    }

    @Override
    public String toString() {
        return "KindOfSickness{" +
                "BloodPressure=" + BloodPressure +
                ", Bmi=" + Bmi +
                ", CholesterolLevel=" + CholesterolLevel +
                ", glucosePer=" + glucosePer +
                ", bodyTemperature=" + bodyTemperature +
                '}';
    }
}
